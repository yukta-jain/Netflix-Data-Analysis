var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
/* GET Hello World page. */
router.get('/helloworld', function(req, res) {
  res.render('helloworld', { title: 'Hello, World!' });
});

/* GET NetflixTitle page. */
router.get('/titlelist', function(req, res) {
    var db = req.db;
    var collection = db.get('netflixtitles');
    collection.find({},{},function(e,docs){
        res.render('titlelist', {
            "titlelist" : docs
        });
    });
});


/* GET New Title page. */
/* GET NetflixTitle page. */
router.get('/newtitle', function(req, res) {
  var db = req.db;
  var collection = db.get('netflixtitles');
  collection.find({},{},function(e,docs){
      res.render('newtitle', {
          "titlelist" : docs
      });
  });
});

/* POST to Add User Service */
router.post('/addtitle', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  //var userName = req.body.username;
  //var userEmail = req.body.useremail;

  var show_id=parseInt(req.body.show_id);
  var type=req.body.type;
  var title=req.body.title;
  var director=req.body.director;
  var cast=req.body.cast;
  var country=req.body.country;
  var date_added=req.body.date_added;
  var release_year=req.body.release_year;
  var rating=req.body.rating;
  var duration=req.body.duration;
  var listed_in=req.body.listed_in;
  var description=req.body.description;

  // Set our collection
  var collection = db.get('netflixtitles');

  // Submit to the DB
  collection.insert({
      "show_id" : show_id,
      "type" : type,
      "title":title,
      "director":director,
      "cast":cast,
      "country":country,
      "date_added":date_added,
      "release_year":release_year,
      "rating":rating,
      "duration":duration,
      "listed_in":listed_in,
      "description":description
      
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem adding the information to the database.");
      }
      else {
          // And forward to success page
          res.redirect("/titlelist");
      }
  });

});


router.get('/delete', function(req, res) {
  var db = req.db;
  var collection = db.get('netflixtitles');
  collection.find({_id:0},{},function(e,docs){
      res.render('delete', {
          "titlelist" : docs
      });
  });
  //res.render('delete', { title: 'Delete a User' });
});

router.post('/queryuser', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var show_id = parseInt(req.body.show_id);
  

  // Set our collection
  var collection = db.get('netflixtitles');
  console.log(show_id);
  // Submit to the DB
  collection.find({
      "show_id": show_id
  },
  {},
  function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem updating the information into the database.");
      }
      else {
          // And forward to success page
          res.render("delete", { "titlelist": doc });
      }
  });

});

router.post('/deleteuser', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var show_id = parseInt(req.body.show_id);
  

  // Set our collection
  var collection = db.get('netflixtitles');

  // Submit to the DB
  collection.remove({
     show_id : show_id
  }, function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem deleting the information from the database.");
      }
      else {
          // And forward to success page
          res.redirect("/titlelist");
      }
  });

});

router.get('/update', function(req, res) {
  var db = req.db;
  var collection = db.get('netflixtitles');
  collection.find({_id:0},{},function(e,docs){
      res.render('update', {
          "titlelist" : docs
      });
  });
  //res.render('update', { title: 'Update database' });
});

router.post('/getuser', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var show_id = parseInt(req.body.show_id);
  

  // Set our collection
  var collection = db.get('netflixtitles');
  console.log(show_id);
  // Submit to the DB
  collection.find({
      "show_id": show_id
  },
  {},
  function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem updating the information into the database.");
      }
      else {
          // And forward to success page
          res.render("update", { "titlelist": doc });
      }
  });

});

router.post('/updateuser', function(req, res) {

  // Set our internal DB variable
  var db = req.db;

  // Get our form values. These rely on the "name" attributes
  var show_id=parseInt(req.body.show_id);
  var type=req.body.type;
  var title=req.body.title;
  var director=req.body.director;
  var cast=req.body.cast;
  var country=req.body.country;
  var date_added=req.body.date_added;
  var release_year=req.body.release_year;
  var rating=req.body.rating;
  var duration=req.body.duration;
  var listed_in=req.body.listed_in;
  var description=req.body.description;


  // Set our collection
  var collection = db.get('netflixtitles');

  // Submit to the DB
  collection.update({
      "show_id": show_id
  },
  {
    $set: {"show_id" : show_id,
    "type" : type,
    "title":title,
    "director":director,
    "cast":cast,
    "country":country,
    "date_added":date_added,
    "release_year":release_year,
    "rating":rating,
    "duration":duration,
    "listed_in":listed_in,
    "description":description
    }
  },
  function (err, doc) {
      if (err) {
          // If it failed, return error
          res.send("There was a problem updating the information into the database.");
      }
      else {
          // And forward to success page
          res.redirect("/titlelist");
      }
  });

});



module.exports = router;
